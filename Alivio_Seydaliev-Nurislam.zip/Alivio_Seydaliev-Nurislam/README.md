### Alivio Landing Page UI

#### Tech Stack

```
HTML
SCSS
JavaScript
FontAwesome
```

#### Preview

```
https://korayguler.github.io/alivio-landing-page-ui/
```

#### Desing

```
https://www.uistore.design/items/alivio-landing-page-for-figma/
```
